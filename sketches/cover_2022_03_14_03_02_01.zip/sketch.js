function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  noFill();
  stroke(0, 255, 0);
  strokeWeight(3);
  ellipse(mouseX, mouseY, 10);
}